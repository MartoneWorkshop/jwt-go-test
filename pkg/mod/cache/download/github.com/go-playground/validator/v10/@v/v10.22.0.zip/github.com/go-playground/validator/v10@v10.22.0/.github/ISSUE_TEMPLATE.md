- [ ] I have looked at the documentation [here](https://pkg.go.dev/github.com/go-playground/validator/v10#section-documentation) first?
- [ ] I have looked at the examples provided that may showcase my question [here](/_examples)?

### Package version eg. v9, v10: 



### Issue, Question or Enhancement:



### Code sample, to showcase or reproduce:

```go

```
